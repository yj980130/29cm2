package member.service;

public class EmailDupliService {

	// 싱글톤
	private static EmailDupliService instance = new EmailDupliService();
	public static EmailDupliService getInstance() {
		return instance;
	}
	private EmailDupliService() { }
	
	
	
	
}
