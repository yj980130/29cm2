package member.persistence.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.util.ConnectionProvider;
import com.util.JdbcUtil;

import member.domain.MemberDTO;
import member.persistence.dao.MemberDAO;

public class MemberDAOImpl implements MemberDAO{
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	// 생성자를 통한 DI
	public MemberDAOImpl(Connection conn) {
		this.conn = conn;
	}

	// Setter를 통한 DI
	public void MemberDAOImpl(Connection conn) {
		this.conn = conn;
	}
		
	// Getter
	public Connection getConn(){
		return this.conn;
	}

	@Override
	public boolean emailCheck(String member_email) throws SQLException {
		return false;
	}

	@Override
	public int emailDupliCheck(String member_email) throws SQLException {
		int rowCount = 0;
		
		try {
			String sql = " SELECT member_email FROM member WHERE member_mail = ? ";
			conn = ConnectionProvider.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) rowCount = 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
			JdbcUtil.close(conn);
		}
		
		return rowCount;
	}

	@Override
	public boolean pwdCheck(String member_pwd) throws SQLException {
		return false;
	}

	@Override
	public int insert(MemberDTO dto) throws SQLException {
		
		int rowCount = 0;
		String sql = "INSERT INTO member "
				   + "(member_id, member_pwd, member_email, member_name ) "
				   + "VALUES "
				   + "(seq_member_id.NEXTVAL, ?, ? ,? ) ";
		
		 this.pstmt = conn.prepareStatement(sql);
		 pstmt.setString(1, dto.getMember_pwd());
		 pstmt.setString(2, dto.getMember_email());
		 pstmt.setString(3, dto.getMember_name());
		 
		rowCount = this.pstmt.executeUpdate();
		this.pstmt.close();
		
		return rowCount;
	}

}
